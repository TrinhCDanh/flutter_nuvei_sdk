//
//  NuveiSimplyConnectSDK.h
//  NuveiSimplyConnectSDK
//
//  Created by Michael Kessler on 04/08/2019.
//  Copyright © 2019 Nuvei. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for NuveiMobileSDK.
FOUNDATION_EXPORT double NuveiSimplyConnectSDKVersionNumber;

//! Project version string for NuveiMobileSDK.
FOUNDATION_EXPORT const unsigned char NuveiSimplyConnectSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NuveiMobileSDK/NuveiMobileSDK.h>


